//
//  ZCAppDelegate.h
//  MultipeerConnectivity_Demo
//
//  Created by ZhangCheng on 14-5-31.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
