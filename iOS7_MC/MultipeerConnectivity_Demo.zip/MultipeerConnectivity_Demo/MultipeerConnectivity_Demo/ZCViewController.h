//
//  ZCViewController.h
//  MultipeerConnectivity_Demo
//
//  Created by ZhangCheng on 14-5-31.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MultipeerConnectivity/MultipeerConnectivity.h>
@interface ZCViewController : UIViewController<MCSessionDelegate,MCNearbyServiceBrowserDelegate,MCBrowserViewControllerDelegate>
{
    //表示设备包含发现设备和建立会话阶段所需的各种属性
    MCPeerID*lockPeerID;
    //对象是最重要的，因为它代表目前的对等点（这个程序将运行的设备）将创建的会话
    MCSession*_session1;
    //广播服务
    MCAdvertiserAssistant* advertiser;
    //发现服务
    MCBrowserViewController* _broswerController;
    //显示数据
    UITextView*_textView;
}
@property(nonatomic,retain)NSMutableArray*dataArray;

@end
